"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Lock, Unlock, Radio } from "lucide-react";
import { useToast } from "@/components/providers/toast-provider";

export function SessionActions({ sessionId, status }: { sessionId: number; status: string }) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { show } = useToast();

  async function setStatus(newStatus: string) {
    setLoading(true);
    try {
      await fetch(`/api/sessions/${sessionId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
      show(newStatus === "locked" ? "Session locked" : newStatus === "completed" ? "Session reopened as completed" : "Session reopened");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  if (status === "in_progress") {
    return (
      <button onClick={() => router.push("/live")} className="btn btn-primary">
        <Radio size={14} /> Resume Live Session
      </button>
    );
  }

  if (status === "locked") {
    return (
      <button disabled={loading} onClick={() => setStatus("completed")} className="btn">
        <Unlock size={14} /> Unlock Session
      </button>
    );
  }

  return (
    <div className="flex gap-2">
      <button disabled={loading} onClick={() => setStatus("in_progress")} className="btn">
        <Radio size={14} /> Reopen Session
      </button>
      <button disabled={loading} onClick={() => setStatus("locked")} className="btn">
        <Lock size={14} /> Lock Session
      </button>
    </div>
  );
}
