"use client";

import { useEffect, useRef, useState } from "react";
import { Plus } from "lucide-react";

const POSITIVE = [1, 2, 3, 5];
const NEGATIVE = [-1, -2, -3, -5];

export function PointPopover({ onPick }: { onPick: (value: number, reason: string) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((v) => !v)} className="btn !px-2 !py-1 text-xs" aria-label="Add points">
        <Plus size={12} /> Points
      </button>
      {open && (
        <div
          className="animate-fade-in absolute right-0 top-full z-20 mt-1.5 w-44 rounded-lg border p-2 shadow-lg"
          style={{ background: "var(--bg-elevated)", borderColor: "var(--border)", boxShadow: "var(--shadow-lg)" }}
        >
          <p className="mb-1 px-1 text-[0.65rem] font-semibold uppercase tracking-wide" style={{ color: "var(--state-present)" }}>
            Add
          </p>
          <div className="mb-2 grid grid-cols-4 gap-1">
            {POSITIVE.map((v) => (
              <button
                key={v}
                onClick={() => {
                  onPick(v, "Quick Adjustment");
                  setOpen(false);
                }}
                className="rounded-md py-1 text-xs font-semibold"
                style={{ background: "var(--state-present-bg)", color: "var(--state-present)" }}
              >
                +{v}
              </button>
            ))}
          </div>
          <p className="mb-1 px-1 text-[0.65rem] font-semibold uppercase tracking-wide" style={{ color: "var(--state-absent)" }}>
            Deduct
          </p>
          <div className="grid grid-cols-4 gap-1">
            {NEGATIVE.map((v) => (
              <button
                key={v}
                onClick={() => {
                  onPick(v, "Quick Adjustment");
                  setOpen(false);
                }}
                className="rounded-md py-1 text-xs font-semibold"
                style={{ background: "var(--state-absent-bg)", color: "var(--state-absent)" }}
              >
                {v}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
