import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  boolean,
  date,
  time,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Students
// ---------------------------------------------------------------------------
export const students = pgTable(
  "students",
  {
    id: serial("id").primaryKey(),
    studentCode: text("student_code").notNull(),
    name: text("name").notNull(),
    className: text("class_name").notNull().default("Mechanics"),
    status: text("status").notNull().default("active"), // active | inactive
    email: text("email"),
    phone: text("phone"),
    avatarColor: text("avatar_color").notNull().default("#2563eb"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("students_code_idx").on(t.studentCode)],
);

// ---------------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------------
export const sessions = pgTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    sessionNumber: integer("session_number").notNull(),
    date: date("date").notNull(),
    title: text("title").notNull(),
    topic: text("topic"),
    startTime: time("start_time"),
    endTime: time("end_time"),
    status: text("status").notNull().default("scheduled"), // scheduled | in_progress | completed | cancelled | locked
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_date_idx").on(t.date)],
);

// ---------------------------------------------------------------------------
// Attendance
// ---------------------------------------------------------------------------
export const attendanceRecords = pgTable(
  "attendance_records",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    sessionId: integer("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    status: text("status").notNull().default("unmarked"), // unmarked | present | absent | late | excused
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("attendance_student_session_idx").on(t.studentId, t.sessionId),
    index("attendance_session_idx").on(t.sessionId),
    index("attendance_student_idx").on(t.studentId),
  ],
);

// ---------------------------------------------------------------------------
// Point categories + events
// ---------------------------------------------------------------------------
export const pointCategories = pgTable("point_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // positive | negative
  defaultValue: integer("default_value").notNull().default(1),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const pointEvents = pgTable(
  "point_events",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    sessionId: integer("session_id").references(() => sessions.id, { onDelete: "cascade" }),
    points: integer("points").notNull(),
    category: text("category").notNull().default("General"),
    reason: text("reason"),
    note: text("note"),
    recordedBy: text("recorded_by").notNull().default("Teacher"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("points_student_idx").on(t.studentId),
    index("points_session_idx").on(t.sessionId),
  ],
);

// ---------------------------------------------------------------------------
// Behavior categories + incidents
// ---------------------------------------------------------------------------
export const behaviorCategories = pgTable("behavior_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // positive | negative
  defaultSeverity: text("default_severity").notNull().default("minor"), // minor | moderate | serious | positive
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const behaviorIncidents = pgTable(
  "behavior_incidents",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    sessionId: integer("session_id").references(() => sessions.id, { onDelete: "cascade" }),
    category: text("category").notNull(),
    severity: text("severity").notNull().default("minor"), // minor | moderate | serious | positive
    description: text("description"),
    relatedPoints: integer("related_points").notNull().default(0),
    note: text("note"),
    status: text("status").notNull().default("open"), // open | reviewed | resolved
    recordedBy: text("recorded_by").notNull().default("Teacher"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("behavior_student_idx").on(t.studentId),
    index("behavior_session_idx").on(t.sessionId),
  ],
);

// ---------------------------------------------------------------------------
// Student notes
// ---------------------------------------------------------------------------
export const studentNotes = pgTable(
  "student_notes",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    sessionId: integer("session_id").references(() => sessions.id, { onDelete: "cascade" }),
    category: text("category").notNull().default("General"), // Academic | Behavior | Participation | Homework | Follow-up | General
    priority: text("priority").notNull().default("normal"), // low | normal | high
    content: text("content").notNull(),
    author: text("author").notNull().default("Teacher"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("notes_student_idx").on(t.studentId)],
);

// ---------------------------------------------------------------------------
// Audit log
// ---------------------------------------------------------------------------
export const auditLog = pgTable(
  "audit_log",
  {
    id: serial("id").primaryKey(),
    entity: text("entity").notNull(),
    entityId: integer("entity_id").notNull(),
    action: text("action").notNull(), // create | update | delete
    previousValue: text("previous_value"),
    newValue: text("new_value"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("audit_entity_idx").on(t.entity, t.entityId)],
);

// ---------------------------------------------------------------------------
// Settings (key-value)
// ---------------------------------------------------------------------------
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});
