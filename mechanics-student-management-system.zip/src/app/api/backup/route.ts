import { NextRequest } from "next/server";
import { db } from "@/db";
import {
  students,
  sessions,
  attendanceRecords,
  pointEvents,
  behaviorIncidents,
  studentNotes,
  behaviorCategories,
  pointCategories,
  settings,
} from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const [
    studentsData,
    sessionsData,
    attendanceData,
    pointsData,
    behaviorsData,
    notesData,
    behaviorCategoriesData,
    pointCategoriesData,
    settingsData,
  ] = await Promise.all([
    db.select().from(students),
    db.select().from(sessions),
    db.select().from(attendanceRecords),
    db.select().from(pointEvents),
    db.select().from(behaviorIncidents),
    db.select().from(studentNotes),
    db.select().from(behaviorCategories),
    db.select().from(pointCategories),
    db.select().from(settings),
  ]);

  const backup = {
    version: 1,
    exportedAt: new Date().toISOString(),
    students: studentsData,
    sessions: sessionsData,
    attendanceRecords: attendanceData,
    pointEvents: pointsData,
    behaviorIncidents: behaviorsData,
    studentNotes: notesData,
    behaviorCategories: behaviorCategoriesData,
    pointCategories: pointCategoriesData,
    settings: settingsData,
  };

  return new Response(JSON.stringify(backup, null, 2), {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="mechanics_backup_${new Date().toISOString().slice(0, 10)}.json"`,
    },
  });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  if (!body || typeof body !== "object" || !Array.isArray(body.students)) {
    return Response.json({ error: "Invalid backup file" }, { status: 400 });
  }

  await db.transaction(async (tx) => {
    await tx.execute(sql`truncate table audit_log, student_notes, behavior_incidents, point_events, attendance_records, sessions, students, behavior_categories, point_categories, settings restart identity cascade`);

    if (body.students?.length) await tx.insert(students).values(body.students.map((s: any) => ({ ...s, createdAt: new Date(s.createdAt) })));
    if (body.sessions?.length)
      await tx.insert(sessions).values(body.sessions.map((s: any) => ({ ...s, createdAt: new Date(s.createdAt), updatedAt: new Date(s.updatedAt) })));
    if (body.attendanceRecords?.length)
      await tx
        .insert(attendanceRecords)
        .values(body.attendanceRecords.map((a: any) => ({ ...a, createdAt: new Date(a.createdAt), updatedAt: new Date(a.updatedAt) })));
    if (body.pointEvents?.length)
      await tx.insert(pointEvents).values(body.pointEvents.map((p: any) => ({ ...p, createdAt: new Date(p.createdAt) })));
    if (body.behaviorIncidents?.length)
      await tx
        .insert(behaviorIncidents)
        .values(body.behaviorIncidents.map((b: any) => ({ ...b, createdAt: new Date(b.createdAt), updatedAt: new Date(b.updatedAt) })));
    if (body.studentNotes?.length)
      await tx.insert(studentNotes).values(body.studentNotes.map((n: any) => ({ ...n, createdAt: new Date(n.createdAt) })));
    if (body.behaviorCategories?.length) await tx.insert(behaviorCategories).values(body.behaviorCategories);
    if (body.pointCategories?.length) await tx.insert(pointCategories).values(body.pointCategories);
    if (body.settings?.length) await tx.insert(settings).values(body.settings);

    await tx.execute(sql`select setval(pg_get_serial_sequence('students','id'), coalesce((select max(id) from students),1))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('sessions','id'), coalesce((select max(id) from sessions),1))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('attendance_records','id'), coalesce((select max(id) from attendance_records),1))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('point_events','id'), coalesce((select max(id) from point_events),1))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('behavior_incidents','id'), coalesce((select max(id) from behavior_incidents),1))`);
    await tx.execute(sql`select setval(pg_get_serial_sequence('student_notes','id'), coalesce((select max(id) from student_notes),1))`);
  });

  return Response.json({ ok: true });
}
