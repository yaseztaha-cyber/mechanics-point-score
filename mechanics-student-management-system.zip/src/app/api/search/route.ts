import { NextRequest } from "next/server";
import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q")?.trim();
  if (!q) return Response.json({ students: [], sessions: [] });

  const studentRows = (
    await db.execute(sql`
      select s.id, s.name, s.student_code as "studentCode",
        coalesce(a.total, 0)::int as sessions,
        coalesce(a.attended, 0)::int as attended,
        coalesce(p.net, 0)::int as "netPoints",
        coalesce(b.total, 0)::int as "behaviorTotal"
      from students s
      left join (
        select student_id, count(*) filter (where status != 'unmarked') as total,
          count(*) filter (where status in ('present','late')) as attended
        from attendance_records group by student_id
      ) a on a.student_id = s.id
      left join (select student_id, sum(points) as net from point_events group by student_id) p on p.student_id = s.id
      left join (
        select student_id, count(*) as total from behavior_incidents where severity != 'positive' group by student_id
      ) b on b.student_id = s.id
      where s.name ilike ${"%" + q + "%"} or s.student_code ilike ${"%" + q + "%"}
      limit 8
    `)
  ).rows as any[];

  const sessionRows = (
    await db.execute(sql`
      select id, session_number as "sessionNumber", title, topic, date
      from sessions where title ilike ${"%" + q + "%"} or topic ilike ${"%" + q + "%"} or cast(date as text) ilike ${"%" + q + "%"}
      order by date desc limit 6
    `)
  ).rows;

  return Response.json({
    students: studentRows.map((s) => ({
      ...s,
      attendanceRate: s.sessions > 0 ? Math.round((s.attended / s.sessions) * 1000) / 10 : 0,
    })),
    sessions: sessionRows,
  });
}
