import { db } from "@/db";
import { students, sessions } from "@/db/schema";
import { sql } from "drizzle-orm";
import { PdfBuilder } from "@/lib/pdf";
import { signed } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET() {
  const studentRows = (
    await db.execute(sql`
      select s.id, s.name, s.student_code as "studentCode",
        coalesce(a.present, 0)::int as present, coalesce(a.absent, 0)::int as absent,
        coalesce(a.late, 0)::int as late, coalesce(a.excused, 0)::int as excused,
        coalesce(p.net, 0)::int as "netPoints",
        coalesce(b.total, 0)::int as "behaviorTotal"
      from students s
      left join (
        select student_id,
          count(*) filter (where status = 'present') as present,
          count(*) filter (where status = 'absent') as absent,
          count(*) filter (where status = 'late') as late,
          count(*) filter (where status = 'excused') as excused
        from attendance_records group by student_id
      ) a on a.student_id = s.id
      left join (select student_id, sum(points) as net from point_events group by student_id) p on p.student_id = s.id
      left join (
        select student_id, count(*) as total from behavior_incidents where severity != 'positive' group by student_id
      ) b on b.student_id = s.id
      where s.status = 'active'
      order by "netPoints" desc nulls last
    `)
  ).rows as any[];

  const allSessions = await db.select().from(sessions);
  const [classTotals] = (
    await db.execute(sql`
      select
        count(*) filter (where status='present')::int as present,
        count(*) filter (where status='absent')::int as absent,
        count(*) filter (where status='late')::int as late,
        count(*) filter (where status='excused')::int as excused
      from attendance_records
    `)
  ).rows as any[];
  const [pointTotals] = (
    await db.execute(sql`
      select coalesce(sum(points) filter (where points>0),0)::int as positive,
        coalesce(sum(points) filter (where points<0),0)::int as negative
      from point_events
    `)
  ).rows as any[];
  const [behaviorTotals] = (
    await db.execute(sql`
      select count(*)::int as total,
        count(*) filter (where severity='positive')::int as positive,
        count(*) filter (where severity='minor')::int as minor,
        count(*) filter (where severity='moderate')::int as moderate,
        count(*) filter (where severity='serious')::int as serious
      from behavior_incidents
    `)
  ).rows as any[];

  const attention = (
    await db.execute(sql`
      with recent_sessions as (select id from sessions order by date desc limit 6)
      select s.name,
        (select count(*) from behavior_incidents bi where bi.student_id = s.id and bi.session_id in (select id from recent_sessions) and bi.severity != 'positive') as incidents,
        (select count(*) from attendance_records ar where ar.student_id = s.id and ar.session_id in (select id from recent_sessions) and ar.status = 'absent') as absences
      from students s where s.status = 'active'
    `)
  ).rows.filter((r: any) => r.incidents >= 2 || r.absences >= 2) as any[];

  const pdf = await PdfBuilder.create("Class Report");
  pdf.heading("Mechanics — Class Performance Report");
  pdf.text(`Generated ${new Date().toLocaleString("en-US")}  ·  ${allSessions.length} sessions  ·  ${studentRows.length} active students`, 9);
  pdf.line();

  pdf.subheading("Class Summary");
  pdf.metricStrip([
    { label: "Present", value: String(classTotals.present) },
    { label: "Absent", value: String(classTotals.absent) },
    { label: "Late", value: String(classTotals.late) },
    { label: "Excused", value: String(classTotals.excused) },
  ]);
  pdf.metricStrip([
    { label: "Points +", value: signed(pointTotals.positive) },
    { label: "Points -", value: signed(pointTotals.negative) },
    { label: "Net Points", value: signed(pointTotals.positive + pointTotals.negative) },
    { label: "Behavior Incidents", value: String(behaviorTotals.total) },
  ]);
  pdf.line();

  pdf.subheading("Behavior Overview");
  pdf.metricStrip([
    { label: "Positive", value: String(behaviorTotals.positive) },
    { label: "Minor", value: String(behaviorTotals.minor) },
    { label: "Moderate", value: String(behaviorTotals.moderate) },
    { label: "Serious", value: String(behaviorTotals.serious) },
  ]);
  pdf.line();

  pdf.subheading("Student Rankings (by Net Points)");
  pdf.row(
    [
      { text: "Student", width: 180, bold: true },
      { text: "Attendance", width: 160, bold: true },
      { text: "Net Pts", width: 80, bold: true },
      { text: "Behavior", width: 90, bold: true },
    ],
    9.5,
  );
  for (const s of studentRows) {
    pdf.row([
      { text: s.name.slice(0, 28), width: 180 },
      { text: `P${s.present} A${s.absent} L${s.late} E${s.excused}`, width: 160 },
      { text: signed(s.netPoints), width: 80 },
      { text: String(s.behaviorTotal), width: 90 },
    ]);
  }
  pdf.line();

  pdf.subheading("Students Requiring Attention (last 6 sessions)");
  if (attention.length === 0) {
    pdf.text("No students currently flagged — class trends look healthy.");
  }
  for (const r of attention) {
    pdf.text(`${r.name} — ${r.incidents} behavior incidents, ${r.absences} absences`, 9.5);
  }

  const bytes = await pdf.bytes();
  return new Response(Buffer.from(bytes), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="mechanics_class_report.pdf"`,
    },
  });
}
