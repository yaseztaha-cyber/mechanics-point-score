import { db } from "@/db";
import { sql } from "drizzle-orm";

export async function getDashboardData() {
  const today = new Date().toISOString().slice(0, 10);

  const [todaySession] = (
    await db.execute(sql`
      select id, session_number as "sessionNumber", date, title, topic, status
      from sessions where date = ${today} order by session_number desc limit 1
    `)
  ).rows as any[];

  let todayStats = null;
  if (todaySession) {
    const [att] = (
      await db.execute(sql`
        select
          count(*) filter (where status = 'present') as present,
          count(*) filter (where status = 'absent') as absent,
          count(*) filter (where status = 'late') as late,
          count(*) filter (where status = 'excused') as excused
        from attendance_records where session_id = ${todaySession.id}
      `)
    ).rows as any[];
    const [pts] = (
      await db.execute(sql`
        select
          coalesce(sum(points) filter (where points > 0), 0) as positive,
          coalesce(sum(points) filter (where points < 0), 0) as negative
        from point_events where session_id = ${todaySession.id}
      `)
    ).rows as any[];
    const [beh] = (
      await db.execute(sql`select count(*) as total from behavior_incidents where session_id = ${todaySession.id}`)
    ).rows as any[];
    todayStats = {
      present: Number(att.present),
      absent: Number(att.absent),
      late: Number(att.late),
      excused: Number(att.excused),
      pointsPositive: Number(pts.positive),
      pointsNegative: Number(pts.negative),
      behaviorTotal: Number(beh.total),
    };
  }

  const [classTotals] = (
    await db.execute(sql`select count(*) as total from students where status = 'active'`)
  ).rows as any[];
  const [sessionTotals] = (await db.execute(sql`select count(*) as total from sessions`)).rows as any[];

  const [attendanceRate] = (
    await db.execute(sql`
      select
        count(*) filter (where status in ('present','late')) as attended,
        count(*) filter (where status in ('present','late','absent')) as valid
      from attendance_records
    `)
  ).rows as any[];
  const rate =
    Number(attendanceRate.valid) > 0
      ? Math.round((Number(attendanceRate.attended) / Number(attendanceRate.valid)) * 1000) / 10
      : 0;

  const recentActivity = (
    await db.execute(sql`
      (select 'attendance' as kind, ar.id, s.name as student_name, ar.status as detail, null::int as points,
        ar.updated_at as ts
       from attendance_records ar join students s on s.id = ar.student_id
       where ar.status != 'unmarked' order by ar.updated_at desc limit 8)
      union all
      (select 'point' as kind, pe.id, s.name as student_name, pe.reason as detail, pe.points,
        pe.created_at as ts
       from point_events pe join students s on s.id = pe.student_id
       order by pe.created_at desc limit 8)
      union all
      (select 'behavior' as kind, bi.id, s.name as student_name, bi.category as detail, bi.related_points as points,
        bi.created_at as ts
       from behavior_incidents bi join students s on s.id = bi.student_id
       order by bi.created_at desc limit 8)
      order by ts desc limit 10
    `)
  ).rows;

  const alerts: { type: string; message: string }[] = [];

  const absenceAlert = (
    await db.execute(sql`
      with recent_sessions as (select id from sessions order by date desc limit 8)
      select s.name, count(*) as absences
      from attendance_records ar
      join students s on s.id = ar.student_id
      where ar.session_id in (select id from recent_sessions) and ar.status = 'absent'
      group by s.name having count(*) >= 3
      order by absences desc limit 5
    `)
  ).rows as any[];
  for (const row of absenceAlert) {
    alerts.push({ type: "attendance", message: `${row.name} has ${row.absences} absences in the last 8 sessions` });
  }

  const behaviorAlert = (
    await db.execute(sql`
      with recent_sessions as (select id from sessions order by date desc limit 6)
      select s.name, count(*) as incidents
      from behavior_incidents bi
      join students s on s.id = bi.student_id
      where bi.session_id in (select id from recent_sessions) and bi.severity != 'positive'
      group by s.name having count(*) >= 3
      order by incidents desc limit 5
    `)
  ).rows as any[];
  for (const row of behaviorAlert) {
    alerts.push({
      type: "behavior",
      message: `${row.name} has ${row.incidents} behavior incidents across the last 6 sessions — follow-up recommended`,
    });
  }

  const pointsAlert = (
    await db.execute(sql`
      select s.name, count(distinct bi.session_id) as c
      from behavior_incidents bi join students s on s.id = bi.student_id
      where bi.severity = 'positive'
      group by s.name
    `)
  ).rows as any[];

  return {
    date: today,
    todaySession: todaySession ?? null,
    todayStats,
    totals: {
      students: Number(classTotals.total),
      sessions: Number(sessionTotals.total),
      attendanceRate: rate,
    },
    recentActivity,
    alerts,
    _unused: pointsAlert.length,
  };
}

export async function getBehaviorDashboardData() {
  const now = new Date();
  const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
  const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString();
  const lastMonthEnd = thisMonthStart;

  const [totals] = (
    await db.execute(sql`
      select
        count(*)::int as total,
        count(*) filter (where severity = 'positive')::int as positive,
        count(*) filter (where severity = 'minor')::int as minor,
        count(*) filter (where severity = 'moderate')::int as moderate,
        count(*) filter (where severity = 'serious')::int as serious
      from behavior_incidents
    `)
  ).rows as any[];

  const [thisMonth] = (
    await db.execute(
      sql`select count(*)::int as c from behavior_incidents where created_at >= ${thisMonthStart} and severity != 'positive'`,
    )
  ).rows as any[];
  const [lastMonth] = (
    await db.execute(
      sql`select count(*)::int as c from behavior_incidents where created_at >= ${lastMonthStart} and created_at < ${lastMonthEnd} and severity != 'positive'`,
    )
  ).rows as any[];

  const categories = (
    await db.execute(sql`
      select category, count(*)::int as count, severity
      from behavior_incidents group by category, severity order by count desc
    `)
  ).rows as any[];
  const categoryTotals = new Map<string, number>();
  for (const c of categories) categoryTotals.set(c.category, (categoryTotals.get(c.category) ?? 0) + c.count);
  const topCategories = Array.from(categoryTotals.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([category, count]) => ({ category, count }));

  const repeatedStudents = (
    await db.execute(sql`
      with recent_sessions as (select id from sessions order by date desc limit 6)
      select s.id, s.name, count(*)::int as incidents
      from behavior_incidents bi
      join students s on s.id = bi.student_id
      where bi.session_id in (select id from recent_sessions) and bi.severity != 'positive'
      group by s.id, s.name having count(*) >= 2
      order by incidents desc limit 10
    `)
  ).rows;

  const recent = (
    await db.execute(sql`
      select bi.id, s.id as "studentId", s.name as "studentName", bi.category, bi.severity,
        bi.description, bi.related_points as "relatedPoints", bi.created_at as "createdAt",
        bi.status, se.title as "sessionTitle"
      from behavior_incidents bi
      join students s on s.id = bi.student_id
      left join sessions se on se.id = bi.session_id
      order by bi.created_at desc limit 20
    `)
  ).rows;

  return {
    totals: totals[0],
    trend: { thisMonth: thisMonth.c, lastMonth: lastMonth.c },
    topCategories,
    repeatedStudents,
    recent,
  };
}

export async function getStudentsList(q?: string, status?: string | null) {
  const result = await db.execute(sql`
    select s.id, s.student_code as "studentCode", s.name, s.class_name as "className",
      s.status, s.email, s.phone, s.avatar_color as "avatarColor", s.created_at as "createdAt",
      coalesce(a.present, 0)::int as present, coalesce(a.absent, 0)::int as absent,
      coalesce(a.late, 0)::int as late, coalesce(a.excused, 0)::int as excused,
      coalesce(p.net, 0)::int as "netPoints",
      coalesce(b.total, 0)::int as "behaviorTotal",
      coalesce(b.positive, 0)::int as "positiveBehavior"
    from students s
    left join (
      select student_id,
        count(*) filter (where status = 'present') as present,
        count(*) filter (where status = 'absent') as absent,
        count(*) filter (where status = 'late') as late,
        count(*) filter (where status = 'excused') as excused
      from attendance_records group by student_id
    ) a on a.student_id = s.id
    left join (
      select student_id, sum(points) as net from point_events group by student_id
    ) p on p.student_id = s.id
    left join (
      select student_id,
        count(*) filter (where severity != 'positive') as total,
        count(*) filter (where severity = 'positive') as positive
      from behavior_incidents group by student_id
    ) b on b.student_id = s.id
    where (${q ? sql`(s.name ilike ${"%" + q + "%"} or s.student_code ilike ${"%" + q + "%"})` : sql`true`})
      and (${status ? sql`s.status = ${status}` : sql`true`})
    order by s.name asc
  `);
  return result.rows;
}

export async function getStudentDetail(id: number) {
  const [student] = (await db.execute(sql`select * from students where id = ${id}`)).rows as any[];
  if (!student) return null;

  const attendance = (
    await db.execute(sql`select id, status, session_id as "sessionId", note, updated_at as "updatedAt" from attendance_records where student_id = ${id}`)
  ).rows as any[];
  const points = (
    await db.execute(
      sql`select * from point_events where student_id = ${id} order by created_at desc`,
    )
  ).rows as any[];
  const behaviors = (
    await db.execute(
      sql`select * from behavior_incidents where student_id = ${id} order by created_at desc`,
    )
  ).rows as any[];
  const notes = (
    await db.execute(sql`select * from student_notes where student_id = ${id} order by created_at desc`)
  ).rows as any[];

  const sessionIds = Array.from(
    new Set([
      ...attendance.map((a) => a.sessionId),
      ...points.map((p) => p.session_id).filter((x) => x != null),
      ...behaviors.map((b) => b.session_id).filter((x) => x != null),
    ]),
  );
  const sessionRows = sessionIds.length
    ? ((await db.execute(sql`select * from sessions where id = any(${sessionIds})`)).rows as any[])
    : [];
  const sessionMap = new Map(sessionRows.map((s) => [s.id, s]));

  const markedAttendance = attendance.filter((a) => a.status !== "unmarked");

  const { attendanceStats, pointStats, behaviorStats } = await import("./analytics");
  const aStats = attendanceStats(markedAttendance.map((a) => ({ status: a.status, sessionId: a.sessionId })));
  const pStats = pointStats(points.map((p) => ({ points: p.points, sessionId: p.session_id, createdAt: p.created_at })));
  const bStats = behaviorStats(
    behaviors.map((b) => ({ severity: b.severity, category: b.category, sessionId: b.session_id, createdAt: b.created_at })),
  );

  type TimelineItem = {
    kind: "attendance" | "point" | "behavior" | "note";
    timestamp: string;
    sessionId: number | null;
    sessionTitle: string | null;
    data: Record<string, unknown>;
  };
  const timeline: TimelineItem[] = [];
  for (const a of markedAttendance) {
    timeline.push({
      kind: "attendance",
      timestamp: a.updatedAt,
      sessionId: a.sessionId,
      sessionTitle: sessionMap.get(a.sessionId)?.title ?? null,
      data: { status: a.status, note: a.note },
    });
  }
  for (const p of points) {
    timeline.push({
      kind: "point",
      timestamp: p.created_at,
      sessionId: p.session_id,
      sessionTitle: p.session_id ? sessionMap.get(p.session_id)?.title ?? null : null,
      data: { points: p.points, category: p.category, reason: p.reason, note: p.note, id: p.id },
    });
  }
  for (const b of behaviors) {
    timeline.push({
      kind: "behavior",
      timestamp: b.updated_at,
      sessionId: b.session_id,
      sessionTitle: b.session_id ? sessionMap.get(b.session_id)?.title ?? null : null,
      data: {
        category: b.category,
        severity: b.severity,
        description: b.description,
        relatedPoints: b.related_points,
        note: b.note,
        id: b.id,
      },
    });
  }
  for (const n of notes) {
    timeline.push({
      kind: "note",
      timestamp: n.created_at,
      sessionId: n.session_id,
      sessionTitle: n.session_id ? sessionMap.get(n.session_id)?.title ?? null : null,
      data: { content: n.content, category: n.category, priority: n.priority, author: n.author, id: n.id },
    });
  }
  timeline.sort((x, y) => new Date(y.timestamp).getTime() - new Date(x.timestamp).getTime());

  const sessionsWithPoints = sessionRows
    .filter((s) => points.some((p) => p.session_id === s.id))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  let cumulative = 0;
  const chart = sessionsWithPoints.map((s) => {
    const total = points.filter((p) => p.session_id === s.id).reduce((acc, p) => acc + p.points, 0);
    cumulative += total;
    return { sessionId: s.id, sessionNumber: s.session_number, label: `S${s.session_number}`, total, cumulative };
  });

  return {
    student,
    stats: { attendance: aStats, points: pStats, behavior: bStats },
    timeline: timeline.slice(0, 150),
    chart,
    notes,
    behaviors,
    points,
  };
}

export async function getSessionDetail(id: number) {
  const [session] = (
    await db.execute(sql`select * from sessions where id = ${id}`)
  ).rows as any[];
  if (!session) return null;

  const attendance = (
    await db.execute(sql`
      select ar.status, ar.student_id as "studentId", s.name as "studentName"
      from attendance_records ar join students s on s.id = ar.student_id
      where ar.session_id = ${id}
    `)
  ).rows as any[];

  const points = (
    await db.execute(sql`
      select pe.id, pe.student_id as "studentId", s.name as "studentName", pe.points, pe.category,
        pe.reason, pe.note, pe.created_at as "createdAt"
      from point_events pe join students s on s.id = pe.student_id
      where pe.session_id = ${id} order by pe.created_at desc
    `)
  ).rows as any[];

  const behaviors = (
    await db.execute(sql`
      select bi.id, bi.student_id as "studentId", s.name as "studentName", bi.category, bi.severity,
        bi.description, bi.related_points as "relatedPoints", bi.created_at as "createdAt"
      from behavior_incidents bi join students s on s.id = bi.student_id
      where bi.session_id = ${id} order by bi.created_at desc
    `)
  ).rows as any[];

  const totalsByStudent = new Map<number, number>();
  for (const p of points) totalsByStudent.set(p.studentId, (totalsByStudent.get(p.studentId) ?? 0) + p.points);
  const topParticipation = Array.from(totalsByStudent.entries())
    .map(([studentId, total]) => ({ studentId, total, name: points.find((p) => p.studentId === studentId)?.studentName ?? "" }))
    .filter((x) => x.total > 0)
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  const summary = {
    present: attendance.filter((a) => a.status === "present").length,
    absent: attendance.filter((a) => a.status === "absent").length,
    late: attendance.filter((a) => a.status === "late").length,
    excused: attendance.filter((a) => a.status === "excused").length,
    unmarked: attendance.filter((a) => a.status === "unmarked").length,
    totalStudents: attendance.length,
    pointsPositive: points.filter((p) => p.points > 0).reduce((s, p) => s + p.points, 0),
    pointsNegative: points.filter((p) => p.points < 0).reduce((s, p) => s + p.points, 0),
    behaviorTotal: behaviors.length,
    behaviorPositive: behaviors.filter((b) => b.severity === "positive").length,
    behaviorMinor: behaviors.filter((b) => b.severity === "minor").length,
    behaviorModerate: behaviors.filter((b) => b.severity === "moderate").length,
    behaviorSerious: behaviors.filter((b) => b.severity === "serious").length,
    topParticipation,
    absentStudents: attendance.filter((a) => a.status === "absent").map((a) => a.studentName),
    followUpBehaviors: behaviors.filter((b) => b.severity === "moderate" || b.severity === "serious").length,
  };

  return { session, summary, points, behaviors, attendance };
}

export async function getSessionsList() {
  const result = await db.execute(sql`
    select se.id, se.session_number as "sessionNumber", se.date, se.title, se.topic,
      se.start_time as "startTime", se.end_time as "endTime", se.status, se.notes,
      se.created_at as "createdAt", se.updated_at as "updatedAt",
      coalesce(a.present, 0)::int as present, coalesce(a.absent, 0)::int as absent,
      coalesce(a.late, 0)::int as late, coalesce(a.excused, 0)::int as excused,
      coalesce(p.positive, 0)::int as "pointsPositive", coalesce(p.negative, 0)::int as "pointsNegative",
      coalesce(b.total, 0)::int as "behaviorTotal"
    from sessions se
    left join (
      select session_id,
        count(*) filter (where status = 'present') as present,
        count(*) filter (where status = 'absent') as absent,
        count(*) filter (where status = 'late') as late,
        count(*) filter (where status = 'excused') as excused
      from attendance_records group by session_id
    ) a on a.session_id = se.id
    left join (
      select session_id,
        sum(points) filter (where points > 0) as positive,
        sum(points) filter (where points < 0) as negative
      from point_events group by session_id
    ) p on p.session_id = se.id
    left join (
      select session_id, count(*) as total from behavior_incidents group by session_id
    ) b on b.session_id = se.id
    order by se.date desc, se.session_number desc
  `);
  return result.rows;
}
